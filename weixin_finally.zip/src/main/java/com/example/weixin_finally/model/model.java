package com.example.weixin_finally.model;

import android.content.Context;

import com.example.weixin_finally.model.dao.UserAccountDao;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 数据模型层全局类
 */
public class model {
    private Context context;
    private ExecutorService executorService = Executors.newCachedThreadPool();//缓存线程池
    private static model model = new model(); //创建对象
    private UserAccountDao userAccountDao;

    private model() {

    }

    //获取单例对象
    public static model getInstance() {
        return model;
    }

    //初始化的方法
    public void init(Context context) {
        this.context = context;
        //创建用户账号数据库的操作类对象
        userAccountDao = new UserAccountDao( this.context );

    }

    //获取全局线程池对象
    public ExecutorService getCachedThreadPool() {

        return executorService;
    }


    //获取数据库的操作类对象
    public UserAccountDao getUserAccountDao() {
        return userAccountDao;

    }

}
