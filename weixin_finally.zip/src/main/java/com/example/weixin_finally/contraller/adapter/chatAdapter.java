package com.example.weixin_finally.contraller.adapter;

import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.weixin_finally.R;

import java.util.List;

/**
 * 聊天界面的设配器
 */
public class chatAdapter extends BaseAdapter {
    private List<String> data;

    public chatAdapter(List<String> list) {
        data = list;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    class Holder {
        TextView textViewLeft;
        TextView textViewRight;
        ImageView friendsImage;
        ImageView myImage;

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder holder;
        if (convertView == null) {
            convertView = LayoutInflater.from( parent.getContext() )
                    .inflate( R.layout.message_layout, null );
            holder = new Holder();
            holder.textViewLeft = convertView.findViewById( R.id.TextViewLeft );
            holder.textViewRight = convertView.findViewById( R.id.TextViewRight );
            holder.friendsImage = convertView.findViewById( R.id.friendsImage );
            holder.myImage = convertView.findViewById( R.id.myImage );
            convertView.setTag( holder );
        }else{
            holder = (Holder) convertView.getTag();
        }
        DisplayMetrics metrics = convertView.getResources().getDisplayMetrics();
        int widthPixels = metrics.widthPixels;
        holder.textViewLeft.setMaxWidth( widthPixels * 3 / 5);
        holder.textViewRight.setMaxWidth( widthPixels * 3 / 5 );


        if (position % 2 == 0) {
            holder.myImage.setVisibility( View.INVISIBLE );
            holder.textViewRight.setVisibility( View.GONE );
            holder.textViewLeft.setText( data.get( position ) );
        } else {
            holder.friendsImage.setVisibility( View.INVISIBLE );
            holder.textViewLeft.setVisibility( View.GONE );
            holder.textViewRight.setText( data.get( position ) );
        }

        return convertView;
    }

    @Override
    public Object getItem(int position) {
        return data.get( position );
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public boolean isEnabled(int position) {
        return false;
    }
}
