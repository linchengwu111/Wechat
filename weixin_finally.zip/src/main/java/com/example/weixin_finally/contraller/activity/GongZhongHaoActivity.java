package com.example.weixin_finally.contraller.activity;

import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.view.MenuItem;
import android.widget.ListView;

import com.example.weixin_finally.R;
import com.example.weixin_finally.View.SideBar;
import com.example.weixin_finally.contraller.adapter.SortAdapter;
import com.example.weixin_finally.contraller.adapter.User;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import me.imid.swipebacklayout.lib.app.SwipeBackActivity;
/**
 * 公众好页面
 */
public class GongZhongHaoActivity  extends SwipeBackActivity {
    private List<User> friendsList;
    private ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.gongzhonghao_layout );
        setTitle( "公众号" );
        ActionBar bar = getSupportActionBar();
        bar.setDisplayHomeAsUpEnabled( true );
        listView = (ListView) findViewById( R.id.listView );
        SideBar sideBar = (SideBar) findViewById( R.id.side_bar );
        friendsList= new ArrayList<>();
        sideBar.setOnStrSelectCallBack(new SideBar.ISideBarSelectCallBack() {
            @Override
            public void onSelectStr(int index, String selectStr) {
                for (int i = 0; i < friendsList.size(); i++) {
                    if (selectStr.equalsIgnoreCase(friendsList.get(i).getFirstLetter())) {
                        listView.setSelection(i); // 选择到首字母出现的位置
                        return;
                    }
                }
            }
        });
        initData();

    }
    private void initData() {
        friendsList = new ArrayList<>();
        friendsList.add(new User("亳州")); // 亳[bó]属于不常见的二级汉字
        friendsList.add(new User("大娃"));
        friendsList.add(new User("二娃"));
        friendsList.add(new User("三娃"));
        friendsList.add(new User("四娃"));
        friendsList.add(new User("五娃"));
        friendsList.add(new User("六娃"));
        friendsList.add(new User("七娃"));
        friendsList.add(new User("喜羊羊"));
        friendsList.add(new User("美羊羊"));
        friendsList.add(new User("懒羊羊"));
        friendsList.add(new User("沸羊羊"));
        friendsList.add(new User("暖羊羊"));
        friendsList.add(new User("慢羊羊"));
        friendsList.add(new User("灰太狼"));
        friendsList.add(new User("红太狼"));
        friendsList.add(new User("孙悟空"));
        friendsList.add(new User("黑猫警长"));
        friendsList.add(new User("舒克"));
        friendsList.add(new User("美猴王"));
        friendsList.add(new User("海尔"));
        friendsList.add(new User("阿凡提"));
        friendsList.add(new User("邋遢大王"));
        friendsList.add(new User("哪吒"));
        friendsList.add(new User("没头脑"));
        friendsList.add(new User("不高兴"));
        friendsList.add(new User("蓝皮鼠"));
        friendsList.add(new User("大脸猫"));
        friendsList.add(new User("大头儿子"));
        friendsList.add(new User("小头爸爸"));
        friendsList.add(new User("蓝猫"));
        friendsList.add(new User("淘气"));
        friendsList.add(new User("叶峰"));
        friendsList.add(new User("楚天歌"));
        friendsList.add(new User("江流儿"));
        friendsList.add(new User("Tom"));
        friendsList.add(new User("Jerry"));
        friendsList.add(new User("12345"));
        friendsList.add(new User("54321"));
        friendsList.add(new User("_(:з」∠)_"));
        friendsList.add(new User("……%￥#￥%#"));
        Collections.sort( friendsList ); // 对list进行排序，需要让User实现Comparable接口重写compareTo方法
        SortAdapter adapter = new SortAdapter(getApplicationContext(), friendsList );
        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

    }
    //设置点击返回键时退出当前页数，返回上一页
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:// 点击返回图标事件
                this.finish();
            default:
                return super.onOptionsItemSelected( item );
        }
    }
}
