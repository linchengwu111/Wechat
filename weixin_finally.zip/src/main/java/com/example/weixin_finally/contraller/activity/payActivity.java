package com.example.weixin_finally.contraller.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.example.weixin_finally.R;
import com.example.weixin_finally.model.model;
import me.imid.swipebacklayout.lib.app.SwipeBackActivity;
/**
 * 支付页面
 */
public class payActivity extends SwipeBackActivity implements View.OnClickListener {
    private Button SHouFuKUan;
    private Button MyPurse;
    private Button xinyongka;
    private Button chongzhi;
    private Button licaitong;
    private Button shenghuojiaofei;
    private Button qbichongzhi;
    private Button chengshifuwu;
    private Button gongyi;
    private Button baoxian;
    private Button didi;
    private Button jingdong;
    private Button meituan;
    private Button dianying;
    private Button chihewanle;
    private Button jiudian;
    private Button pinduoduo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.layout_me_pay );
        setTitle( "支付" );
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled( true );
        initView();

    }

    private void initView() {
        SHouFuKUan = (Button) findViewById( R.id.shoufukuan );
        MyPurse = (Button) findViewById( R.id.MyPurse );
        xinyongka = (Button) findViewById( R.id.xinyongka );
        chongzhi = (Button) findViewById( R.id.chongzhi );
        licaitong = (Button) findViewById( R.id.licaitong );
        shenghuojiaofei = (Button) findViewById( R.id.shenghuojiaofei );
        qbichongzhi = (Button) findViewById( R.id.qbichongzhi );
        chengshifuwu = (Button) findViewById( R.id.chengshifuwu );
        gongyi = (Button) findViewById( R.id.gongyi );
        baoxian = (Button) findViewById( R.id.baoxian );
        didi = (Button) findViewById( R.id.didi );
        jingdong = (Button) findViewById( R.id.jingdong );
        meituan = (Button) findViewById( R.id.meituan );
        dianying = (Button) findViewById( R.id.dianying );
        chihewanle = (Button) findViewById( R.id.chihewanle );
        jiudian = (Button) findViewById( R.id.jiudian );
        pinduoduo = (Button) findViewById( R.id.pinduoduo );
        SHouFuKUan.setOnClickListener( this );
        MyPurse.setOnClickListener( this );
        xinyongka.setOnClickListener( this );
        chongzhi.setOnClickListener( this );
        licaitong.setOnClickListener( this );
        shenghuojiaofei.setOnClickListener( this );
        qbichongzhi.setOnClickListener( this );
        chengshifuwu.setOnClickListener( this );
        gongyi.setOnClickListener( this );
        baoxian.setOnClickListener( this );
        didi.setOnClickListener( this );
        jingdong.setOnClickListener( this );
        meituan.setOnClickListener( this );
        dianying.setOnClickListener( this );
        chihewanle.setOnClickListener( this );
        jiudian.setOnClickListener( this );
        pinduoduo.setOnClickListener( this );

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:// 点击返回图标事件
                this.finish();
            default:
                return super.onOptionsItemSelected( item );
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.shoufukuan:
                model.getInstance().getCachedThreadPool().execute( new Runnable() {
                    @Override
                    public void run() {
                        Uri uri = Uri.parse( "http://www.baidu.com" );
                        Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                        startActivity( intent );
                    }
                } );
                break;
            case R.id.MyPurse:
                model.getInstance().getCachedThreadPool().execute( new Runnable() {
                    @Override
                    public void run() {
                        Uri uri = Uri.parse( "http://www.baidu.com" );
                        Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                        startActivity( intent );
                    }
                } );
                break;
            case R.id.xinyongka:
                model.getInstance().getCachedThreadPool().execute( new Runnable() {
                    @Override
                    public void run() {
                        Uri uri = Uri.parse( "http://www.baidu.com" );
                        Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                        startActivity( intent );
                    }
                } );
                break;
            case R.id.chongzhi:
                model.getInstance().getCachedThreadPool().execute( new Runnable() {
                    @Override
                    public void run() {
                        Uri uri = Uri.parse( "http://www.baidu.com" );
                        Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                        startActivity( intent );
                    }
                } );
                break;
            case R.id.licaitong:
                model.getInstance().getCachedThreadPool().execute( new Runnable() {
                    @Override
                    public void run() {
                        Uri uri = Uri.parse( "http://www.baidu.com" );
                        Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                        startActivity( intent );
                    }
                } );
                break;
            case R.id.shenghuojiaofei:
                model.getInstance().getCachedThreadPool().execute( new Runnable() {
                    @Override
                    public void run() {
                        Uri uri = Uri.parse( "http://www.baidu.com" );
                        Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                        startActivity( intent );
                    }
                } );
                break;
            case R.id.qbichongzhi:
                model.getInstance().getCachedThreadPool().execute( new Runnable() {
                    @Override
                    public void run() {
                        Uri uri = Uri.parse( "http://www.baidu.com" );
                        Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                        startActivity( intent );
                    }
                } );
                break;
            case R.id.chengshifuwu:
                model.getInstance().getCachedThreadPool().execute( new Runnable() {
                    @Override
                    public void run() {
                        Uri uri = Uri.parse( "http://www.baidu.com" );
                        Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                        startActivity( intent );
                    }
                } );
                break;
            case R.id.gongyi:
                model.getInstance().getCachedThreadPool().execute( new Runnable() {
                    @Override
                    public void run() {
                        Uri uri = Uri.parse( "http://www.baidu.com" );
                        Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                        startActivity( intent );
                    }
                } );
                break;
            case R.id.baoxian:
                model.getInstance().getCachedThreadPool().execute( new Runnable() {
                    @Override
                    public void run() {
                        Uri uri = Uri.parse( "http://www.baidu.com" );
                        Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                        startActivity( intent );
                    }
                } );
                break;
            case R.id.didi:
                model.getInstance().getCachedThreadPool().execute( new Runnable() {
                    @Override
                    public void run() {
                        Uri uri = Uri.parse( "http://www.baidu.com" );
                        Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                        startActivity( intent );
                    }
                } );
                break;
            case R.id.jingdong:
                model.getInstance().getCachedThreadPool().execute( new Runnable() {
                    @Override
                    public void run() {
                        Uri uri = Uri.parse( "http://www.baidu.com" );
                        Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                        startActivity( intent );
                    }
                } );
                break;
            case R.id.meituan:
                model.getInstance().getCachedThreadPool().execute( new Runnable() {
                    @Override
                    public void run() {
                        Uri uri = Uri.parse( "http://www.baidu.com" );
                        Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                        startActivity( intent );
                    }
                } );
                break;
            case R.id.dianying:
                model.getInstance().getCachedThreadPool().execute( new Runnable() {
                    @Override
                    public void run() {
                        Uri uri = Uri.parse( "http://www.baidu.com" );
                        Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                        startActivity( intent );
                    }
                } );
                break;
            case R.id.chihewanle:
                model.getInstance().getCachedThreadPool().execute( new Runnable() {
                    @Override
                    public void run() {
                        Uri uri = Uri.parse( "http://www.baidu.com" );
                        Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                        startActivity( intent );
                    }
                } );
                break;
            case R.id.jiudian:
                model.getInstance().getCachedThreadPool().execute( new Runnable() {
                    @Override
                    public void run() {
                        Uri uri = Uri.parse( "http://www.baidu.com" );
                        Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                        startActivity( intent );
                    }
                } );
                break;
            case R.id.pinduoduo:
                model.getInstance().getCachedThreadPool().execute( new Runnable() {
                    @Override
                    public void run() {
                        Uri uri = Uri.parse( "http://www.baidu.com" );
                        Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                        startActivity( intent );
                    }
                } );
                break;
        }
    }
}
