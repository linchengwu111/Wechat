package com.example.weixin_finally.contraller.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.view.MenuItem;
import android.widget.TextView;

import com.example.weixin_finally.R;

import me.imid.swipebacklayout.lib.app.SwipeBackActivity;
/**
 * 点通讯录好友的页面信息
 */
public class friendsMessageActivity extends SwipeBackActivity {
    private TextView friendsName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.friends_layout );
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled( true );
        friendsName = (TextView) findViewById( R.id.friendsUsername );
        Intent intent = getIntent();
        String name = intent.getStringExtra( "friendsName" );
        friendsName.setText( name );

    }
    //设置点击返回键时退出当前页数，返回上一页
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:// 点击返回图标事件
                this.finish();
            default:
                return super.onOptionsItemSelected( item );
        }
    }

}
