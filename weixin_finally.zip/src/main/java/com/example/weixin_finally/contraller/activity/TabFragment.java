package com.example.weixin_finally.contraller.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.weixin_finally.R;
import com.example.weixin_finally.View.SideBar;
import com.example.weixin_finally.View.itemView;
import com.example.weixin_finally.contraller.adapter.SortAdapter;
import com.example.weixin_finally.contraller.adapter.User;
import com.example.weixin_finally.contraller.adapter.weChatAdapter;
import com.example.weixin_finally.model.model;
import com.lcodecore.tkrefreshlayout.RefreshListenerAdapter;
import com.lcodecore.tkrefreshlayout.TwinklingRefreshLayout;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;
/**
 * 对滑动和点击所产生的数据进行分析，主要在这个activity进行操作
 */
public class TabFragment extends Fragment implements AdapterView.OnItemClickListener {
    private String mTitle;
    private ArrayList<User> friendsList;
    private ListView listView;
    private ArrayList<String> mweChatData = new ArrayList<>();//微信的数据

    private static final String BUNDLE_KEY_TITLE = "key_title";

    public static TabFragment newInstance(String title) {
        Bundle bundle = new Bundle();
        bundle.putString( BUNDLE_KEY_TITLE, title );
        TabFragment tabfragment = new TabFragment();
        tabfragment.setArguments( bundle );
        return tabfragment;
    }



    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        Bundle arguments = getArguments();
        if (arguments != null) {
            mTitle = arguments.getString( BUNDLE_KEY_TITLE, "" );
        }
    }

    @SuppressLint({"SetTextI18n", "InflateParams"})
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = null;
        //不同的数据过来，判断数据的名称，返回不同的xml页面
        switch (mTitle) {
            case "微信": {
                view = inflater.inflate( R.layout.activity_wechat, null );
                //1.得到微信界面的ListView
                //微信首页的布局
                ListView mlvWeChat = view.findViewById( R.id.lvWeChat );
                //2.创建一个weChatAdapter方法，继承baseAdapter
                final weChatAdapter meChatAdapter = new weChatAdapter();
                //3.创建一个方法，把ArrayList的数据传输过去
                meChatAdapter.setData( getMweChatData( mweChatData ) );
                //4.把meChat_adapter的数据放在微信界面上
                mlvWeChat.setAdapter( meChatAdapter );
                //5.刷新meChat_adapter
                meChatAdapter.notifyDataSetChanged();
                mlvWeChat.setOnItemClickListener(this);
                TwinklingRefreshLayout refreshLayout = view.findViewById( R.id.TwinklingRefreshLayout );
                refreshLayout.setOnRefreshListener( new RefreshListenerAdapter() {
                    @Override
                    public void onRefresh(final TwinklingRefreshLayout refreshLayout) {
                        super.onRefresh( refreshLayout );
                        new Handler().postDelayed( new Runnable() {
                            @Override
                            public void run() {
                                refreshLayout.finishRefreshing();
                                for (int i = 0; i < 3; i++) {
                                    mweChatData.add( i, "新添加的好友" + (i + 1) );
                                }
                                meChatAdapter.notifyDataSetChanged();
                                refreshLayout.finishLoadmore();
                            }
                        },2000);
                    }

                    @Override
                    public void onLoadMore(final TwinklingRefreshLayout refreshLayout) {
                        super.onLoadMore( refreshLayout );
                        new Handler().postDelayed( new Runnable() {
                            @Override
                            public void run() {
                                for (int i = 0; i < 3; i++) {
                                    mweChatData.add(  "新添加的好友" + (i + 1) );
                                }
                                meChatAdapter.notifyDataSetChanged();
                                refreshLayout.finishLoadmore();

                            }
                        }, 2000 );
                    }
                } );

                break;
            }
            case "通讯录": {
                view = inflater.inflate( R.layout.activity_address_list, container, false );
                 listView = view.findViewById( R.id.listView );
                SideBar sideBar = view.findViewById( R.id.side_bar );
                friendsList= new ArrayList<>();
                sideBar.setOnStrSelectCallBack(new SideBar.ISideBarSelectCallBack() {
                    @Override
                    public void onSelectStr(int index, String selectStr) {
                        for (int i = 0; i < friendsList.size(); i++) {
                            if (selectStr.equalsIgnoreCase(friendsList.get(i).getFirstLetter())) {
                                listView.setSelection(i); // 选择到首字母出现的位置
                                return;
                            }
                        }
                    }
                });
                initData();
                listView.setOnItemClickListener( new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                        if (position == 0) {
                            Toast.makeText( getContext(), "你点击了新的朋友", Toast.LENGTH_SHORT ).show();
                        }
                        if (position == 1) {
                            Toast.makeText( getContext(), "你点击了群聊", Toast.LENGTH_SHORT ).show();
                        }
                        if (position == 2) {
                            Toast.makeText( getContext(), "你点击了标签", Toast.LENGTH_SHORT ).show();
                        }
                        if (position == 3) {
                            Intent intent = new Intent( getContext(), GongZhongHaoActivity.class );
                            startActivity( intent );
                        }

                        if (position > 3) {
                            Intent intent = new Intent( getContext(), friendsMessageActivity.class );
                            intent.putExtra( "friendsName", friendsList.get( position ).getName() );
                            startActivity( intent );
                        }

                    }
                } );
                break;
            }
            case "发现":
                view = inflater.inflate( R.layout.activity_discover, container, false );
                itemView itemView1 = view.findViewById( R.id.findItem1 );
                itemView itemView2 = view.findViewById( R.id.findItem2 );
                itemView itemView3 = view.findViewById( R.id.findItem3 );
                itemView itemView4 = view.findViewById( R.id.findItem4 );
                itemView itemView5 = view.findViewById( R.id.findItem5 );
                itemView itemView6 = view.findViewById( R.id.findItem6 );
                itemView1.setItemView( R.drawable.finds_1, "朋友圈", true );
                itemView2.setItemView( R.drawable.finds_2, "扫一扫", true );
                itemView3.setItemView( R.drawable.find_3, "看一看", true );
                itemView4.setItemView( R.drawable.find_4, "搜一搜", true );
                itemView5.setItemView( R.drawable.find_5, "附近的人", true );
                itemView6.setItemView( R.drawable.find_6, "购物", true );
                itemView1.setOnItemViewClickListener( new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText( getContext(), "你点击了朋友圈", Toast.LENGTH_SHORT ).show();
                        model.getInstance().getCachedThreadPool().execute( new Runnable() {
                            @Override
                            public void run() {
                                Uri uri = Uri.parse( "https://v.qq.com/" );
                                Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                                startActivity( intent );
                            }
                        } );
                    }
                } );
                itemView2.setOnItemViewClickListener( new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText( getContext(), "你点击了扫一扫", Toast.LENGTH_SHORT ).show();
                        model.getInstance().getCachedThreadPool().execute( new Runnable() {
                            @Override
                            public void run() {
                                Uri uri = Uri.parse( "http://www.jingdong.com" );
                                Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                                startActivity( intent );
                            }
                        } );
                    }
                } );
                itemView3.setOnItemViewClickListener( new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText( getContext(), "你点击了看一看", Toast.LENGTH_SHORT ).show();
                        model.getInstance().getCachedThreadPool().execute( new Runnable() {
                            @Override
                            public void run() {
                                Uri uri = Uri.parse( "http://www.jingdong.com" );
                                Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                                startActivity( intent );
                            }
                        } );
                    }
                } );
                itemView4.setOnItemViewClickListener( new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText( getContext(), "你点击了搜一搜", Toast.LENGTH_SHORT ).show();
                        model.getInstance().getCachedThreadPool().execute( new Runnable() {
                            @Override
                            public void run() {
                                Uri uri = Uri.parse( "http://www.jingdong.com" );
                                Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                                startActivity( intent );
                            }
                        } );
                    }
                } );
                itemView5.setOnItemViewClickListener( new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText( getContext(), "你点击了附近的人", Toast.LENGTH_SHORT ).show();
                        model.getInstance().getCachedThreadPool().execute( new Runnable() {
                            @Override
                            public void run() {
                                Uri uri = Uri.parse( "http://www.douyin.com" );
                                Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                                startActivity( intent );
                            }
                        } );
                    }
                } );
                itemView6.setOnItemViewClickListener( new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText( getContext(), "你点击了购物", Toast.LENGTH_SHORT ).show();
                        model.getInstance().getCachedThreadPool().execute( new Runnable() {
                            @Override
                            public void run() {
                                Uri uri = Uri.parse( "http://www.jingdong.com" );
                                Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                                startActivity( intent );
                            }
                        } );
                    }
                } );
                break;
            case "我":
                //用于“我”的名称和账号
                view = inflater.inflate( R.layout.activity_me, container, false );
                //注册时候的昵称
                TextView name = view.findViewById( R.id.me_tv1 );
                //注册时候的账号
                TextView username = view.findViewById( R.id.me_tv2 );
                String[] mData = null;
                try {
                    //找到文件  getCacheDir
                    File file = new File( Objects.requireNonNull( getActivity() ).getCacheDir(), "/weChatInfo.txt" );
                    BufferedReader reader = new BufferedReader( new FileReader( file ) );
                    String line = reader.readLine();
                    //4.把数据按“#”分割成几部分
                    if (line.contains( "#" )) {
                        mData = line.split( "#" );
                    }
                    assert mData != null;
                    name.setText( mData[0] );
                    username.setText( "微信号：" + mData[1] );

                } catch (IOException e) {
                    e.printStackTrace();
                }
                itemView meItem1 = view.findViewById( R.id.meItem1 );
                itemView meItem2 = view.findViewById( R.id.meItem2 );
                itemView meItem3 = view.findViewById( R.id.meItem3 );
                itemView meItem4 = view.findViewById( R.id.meItem4 );
                itemView meItem5 = view.findViewById( R.id.meItem5 );
                itemView meItem6 = view.findViewById( R.id.meItem6 );
                meItem1.setItemView( R.drawable.me_item1, "支付", true );
                meItem2.setItemView( R.drawable.me_item2, "收藏", true );
                meItem3.setItemView( R.drawable.me_item3, "相册", true );
                meItem4.setItemView( R.drawable.me_item4, "卡包", true );
                meItem5.setItemView( R.drawable.me_item5, "表情", true );
                meItem6.setItemView( R.drawable.me_item6, "设置", true );
                RelativeLayout relativeLayout = view.findViewById( R.id.me_data );
                relativeLayout.setOnClickListener( new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent( getContext(), meMessageActivity.class );
                        startActivity( intent );

                    }
                } );
                meItem1.setOnItemViewClickListener( new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent( getContext(), payActivity.class );
                        startActivity( intent );
                    }
                } );
                meItem2.setOnItemViewClickListener( new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText( getContext(), "你点击了购物", Toast.LENGTH_SHORT ).show();
                        model.getInstance().getCachedThreadPool().execute( new Runnable() {
                            @Override
                            public void run() {
                                Uri uri = Uri.parse( "http://www.jingdong.com" );
                                Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                                startActivity( intent );
                            }
                        } );
                    }
                } );
                meItem3.setOnItemViewClickListener( new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText( getContext(), "你点击了购物", Toast.LENGTH_SHORT ).show();
                        model.getInstance().getCachedThreadPool().execute( new Runnable() {
                            @Override
                            public void run() {
                                Uri uri = Uri.parse( "http://www.jingdong.com" );
                                Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                                startActivity( intent );
                            }
                        } );
                    }
                } );
                meItem4.setOnItemViewClickListener( new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText( getContext(), "你点击了购物", Toast.LENGTH_SHORT ).show();
                        model.getInstance().getCachedThreadPool().execute( new Runnable() {
                            @Override
                            public void run() {
                                Uri uri = Uri.parse( "http://www.jingdong.com" );
                                Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                                startActivity( intent );
                            }
                        } );
                    }
                } );
                meItem5.setOnItemViewClickListener( new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText( getContext(), "你点击了购物", Toast.LENGTH_SHORT ).show();
                        model.getInstance().getCachedThreadPool().execute( new Runnable() {
                            @Override
                            public void run() {
                                Uri uri = Uri.parse( "http://www.jingdong.com" );
                                Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                                startActivity( intent );
                            }
                        } );
                    }
                } );
                meItem6.setOnItemViewClickListener( new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText( getContext(), "你点击了购物", Toast.LENGTH_SHORT ).show();
                        model.getInstance().getCachedThreadPool().execute( new Runnable() {
                            @Override
                            public void run() {
                                Uri uri = Uri.parse( "http://www.jingdong.com" );
                                Intent intent = new Intent( Intent.ACTION_VIEW, uri );
                                startActivity( intent );
                            }
                        } );
                    }
                } );

                break;
        }
        return view;

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated( view, savedInstanceState );
    }

    private void initData() {
        friendsList = new ArrayList<>();
        friendsList.add(new User("亳州")); // 亳[bó]属于不常见的二级汉字
        friendsList.add(new User("大娃"));
        friendsList.add(new User("二娃"));
        friendsList.add(new User("三娃"));
        friendsList.add(new User("四娃"));
        friendsList.add(new User("五娃"));
        friendsList.add(new User("六娃"));
        friendsList.add(new User("七娃"));
        friendsList.add(new User("喜羊羊"));
        friendsList.add(new User("美羊羊"));
        friendsList.add(new User("懒羊羊"));
        friendsList.add(new User("沸羊羊"));
        friendsList.add(new User("暖羊羊"));
        friendsList.add(new User("慢羊羊"));
        friendsList.add(new User("灰太狼"));
        friendsList.add(new User("红太狼"));
        friendsList.add(new User("孙悟空"));
        friendsList.add(new User("黑猫警长"));
        friendsList.add(new User("舒克"));
        friendsList.add(new User("美猴王"));
        friendsList.add(new User("海尔"));
        friendsList.add(new User("阿凡提"));
        friendsList.add(new User("邋遢大王"));
        friendsList.add(new User("哪吒"));
        friendsList.add(new User("没头脑"));
        friendsList.add(new User("不高兴"));
        friendsList.add(new User("蓝皮鼠"));
        friendsList.add(new User("大脸猫"));
        friendsList.add(new User("大头儿子"));
        friendsList.add(new User("小头爸爸"));
        friendsList.add(new User("蓝猫"));
        friendsList.add(new User("淘气"));
        friendsList.add(new User("叶峰"));
        friendsList.add(new User("楚天歌"));
        friendsList.add(new User("江流儿"));
        friendsList.add(new User("Tom"));
        friendsList.add(new User("Jerry"));
        friendsList.add(new User("12345"));
        friendsList.add(new User("54321"));
        friendsList.add(new User("_(:з」∠)_"));
        friendsList.add(new User("……%￥#￥%#"));
        Collections.sort( friendsList ); // 对list进行排序，需要让User实现Comparable接口重写compareTo方法
        friendsList.add(0,new User("新的朋友"));
        friendsList.add(1,new User("群聊"));
        friendsList.add(2,new User("标签"));
        friendsList.add(3,new User("公众号"));

        SortAdapter adapter = new SortAdapter(getContext(), friendsList );
        listView.setAdapter(adapter);
        adapter.notifyDataSetChanged();

    }


    //微信界面的文字信息
    public ArrayList<String> getMweChatData(ArrayList<String> mweChatData) {
        mweChatData.add( "Aaron 郭富城" );
        mweChatData.add( "Ada 蔡少芬" );
        mweChatData.add( "Angelica 李心洁" );
        mweChatData.add( "Auguste 关德辉" );
        mweChatData.add( "Baby 张含韵" );
        mweChatData.add( "Belinda 韩君婷" );
        mweChatData.add( "Candy 卢巧音" );
        mweChatData.add( "Dawn 曾建明" );
        mweChatData.add( "Denise 何韵诗" );
        mweChatData.add( "Edison 陈冠希" );
        mweChatData.add( "Ellis 邓肇欣" );
        mweChatData.add( "Ina 吕怡慧" );
        mweChatData.add( "Jaycee 房祖明" );
        mweChatData.add( "Macy 陈美诗" );
        mweChatData.add( "June 陈琪" );
        mweChatData.add( "Louis 古天乐" );
        mweChatData.add( "Lulu 盖世宝" );
        mweChatData.add( "Aaron 郭富城" );
        mweChatData.add( "Margie 曾华倩" );
        mweChatData.add( "Mandy 蒋雅文" );
        return mweChatData;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent( getContext(), ChatActivity.class );
        intent.putExtra( "title", mweChatData.get( position ) );
        startActivity( intent );

    }
}
