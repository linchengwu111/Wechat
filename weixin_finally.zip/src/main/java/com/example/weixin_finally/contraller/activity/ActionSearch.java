package com.example.weixin_finally.contraller.activity;

import android.app.Activity;
import android.os.Bundle;

import com.example.weixin_finally.R;

public class ActionSearch extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_action_search2 );
    }

}
