package com.example.weixin_finally.contraller.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;

import com.example.weixin_finally.R;

import java.io.File;
/**
 * 进入微信的等待3秒进入
 */

public class splashActivity extends AppCompatActivity {

    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage( msg );
            //如果当前的handler已经退出，那么不处理handler里面的消息
            if (isFinishing()) {
                return;
            }
            //判断进入登录界面还是主页面
            toMainOrLogin();

        }
    };

    private void toMainOrLogin() {
        new Thread() {
            @Override
            public void run() {
                super.run();
                //1.找到文件
                File file = new File( getCacheDir(), "/weChatInfo.txt" );
                //2.如果文件存在，并且有数据
                if (file.exists() && file.length() > 0) {//登录过
                    //获取到当前登录用户的信息
                    //跳转到主页面
                    Intent intent = new Intent( splashActivity.this, MainActivity.class );
                    startActivity( intent );

                } else {//没登录过
                    //跳转到登录界面
                    Intent intent = new Intent( splashActivity.this, RegisterLogin.class );
                    startActivity( intent );

                }
            }
        }.start();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_splash );
        ActionBar supportActionBar = getSupportActionBar();
        if (supportActionBar != null) {
            supportActionBar.hide();
        }
        //延迟三秒
        handler.sendMessageDelayed( Message.obtain(), 3000 );

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //移除消息
        handler.removeCallbacksAndMessages( null );

    }
}
