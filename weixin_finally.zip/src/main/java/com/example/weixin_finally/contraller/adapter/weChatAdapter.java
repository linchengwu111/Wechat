package com.example.weixin_finally.contraller.adapter;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.weixin_finally.R;

import java.util.ArrayList;
/**
 * 微信首页的设配器
 */
public class weChatAdapter extends BaseAdapter {
    private ArrayList<String> mData;

    public void setData(ArrayList<String> mweChatData) {
        mData = mweChatData;
    }

    @Override
    public int getCount() {
        return mData != null ? mData.size() : 0;
    }

    @SuppressLint("InflateParams")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        TextView tv ;
        if (convertView == null) {
            convertView = LayoutInflater.from( parent.getContext() ).inflate(
                    R.layout.layout_list01, null );
            tv = convertView.findViewById( R.id.list_tv );
            convertView.setTag( tv );
        } else {
            tv = (TextView) convertView.getTag();
        }
        tv.setText( mData.get( position ) );
        return convertView;

    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }


}
