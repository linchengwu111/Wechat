package com.example.weixin_finally.contraller.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.weixin_finally.R;
import com.example.weixin_finally.contraller.adapter.chatAdapter;
import java.util.ArrayList;
import java.util.List;
/**
 * 聊天界面的activity
 */
import me.imid.swipebacklayout.lib.app.SwipeBackActivity;

public class ChatActivity extends SwipeBackActivity {
    private ListView listView;
    private Button sendButton;
    private Button open;
    private EditText editText;
    private List<String> list = new ArrayList<>();
    private chatAdapter chatAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.chat_layout );
        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled( true );
        Intent intent = getIntent();
        String title = intent.getStringExtra( "title" );
        setTitle( title );


        initView();
    }

    private void initView() {
        sendButton = (Button) findViewById( R.id.SendButton );
        listView = (ListView) findViewById( R.id.myChatListView );
        listView.setDividerHeight( 0 );
        editText = (EditText) findViewById( R.id.EditTextSend );
        open = (Button) findViewById( R.id.dakai );
        list.add( "hello，师兄，师姐！" );
        chatAdapter = new chatAdapter( list );
        listView.setAdapter( chatAdapter );


        editText.addTextChangedListener( new myTextWatcher() );
        sendButton.setOnClickListener( new myOnclickListener() );

    }


    public class myTextWatcher implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            String text = editText.getText().toString();
            if (text.equals( "" ) || text.isEmpty()) {
                open.setVisibility( View.VISIBLE );
                sendButton.setVisibility( View.GONE );

            } else {
                open.setVisibility( View.GONE );
                sendButton.setVisibility( View.VISIBLE );
            }
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            String text = editText.getText().toString();
            if (text.equals( "" ) || text.isEmpty()) {
                open.setVisibility( View.VISIBLE );
                sendButton.setVisibility( View.GONE );

            } else {
                open.setVisibility( View.GONE );
                sendButton.setVisibility( View.VISIBLE );
            }
        }

        @Override
        public void afterTextChanged(Editable s) {
            String text = editText.getText().toString();
            if (text.equals( "" ) || text.isEmpty()) {
                open.setVisibility( View.VISIBLE );
                sendButton.setVisibility( View.GONE );

            } else {
                open.setVisibility( View.GONE );
                sendButton.setVisibility( View.VISIBLE );
            }
        }

    }

    //设置点击返回键时退出当前页数，返回上一页
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            this.finish();
        }
        return super.onOptionsItemSelected( item );
    }

    private class myOnclickListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            String sendText = editText.getText().toString();
            list.add( sendText );
            list.add( sendText );
            chatAdapter.notifyDataSetChanged();
            editText.setText( "" );
            //设置当前位置选中
            listView.setSelection( list.size()  );

        }
    }
}


