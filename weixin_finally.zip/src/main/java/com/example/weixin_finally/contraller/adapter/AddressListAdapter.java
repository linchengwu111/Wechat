package com.example.weixin_finally.contraller.adapter;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.weixin_finally.R;
import com.example.weixin_finally.model.bean.message;

import java.util.ArrayList;

/**
 * 通讯录好友的设配器
 */
public class AddressListAdapter extends BaseAdapter {
    private ArrayList<message> mData;

    public void setData(ArrayList<message> mweChatData) {
        mData = mweChatData;
    }

    @Override
    public int getCount() {
        return mData != null ? mData.size() : 0;
    }

    @SuppressLint("InflateParams")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        data data;
        if (convertView == null) {
            convertView = LayoutInflater.from( parent.getContext() ).inflate(
                    R.layout.layout_list, null );
            data = new data();
            data.tv = convertView.findViewById( R.id.list_tv );
            data.imageView = convertView.findViewById( R.id.imageFriends );
            convertView.setTag( data );
        } else {
            data = (data) convertView.getTag();
        }

        data.tv.setText( mData.get( position ).getText() );
        data.imageView.setImageResource( mData.get( position ).getImageId() );

        return convertView;

    }

    class data {
        TextView tv;
        ImageView imageView;

    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }


}
