package com.example.weixin_finally.contraller.activity;

import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.app.ActionBar;
import android.view.MenuItem;
import android.widget.TextView;

import com.example.weixin_finally.R;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Objects;

import me.imid.swipebacklayout.lib.app.SwipeBackActivity;
/**
 * 个人信息界面
 */
public class meMessageActivity extends SwipeBackActivity {

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.me_message_layout );
        setTitle( "个人信息" );
        ActionBar actionBar = getSupportActionBar();
        assert actionBar != null;
        actionBar.setDisplayHomeAsUpEnabled( true );
        TextView meTextName = (TextView) findViewById( R.id.meTextName );
        TextView meWeChatUsername = (TextView) findViewById( R.id.meWeChatUsername );
        String[] mData = null;
        try {
            //找到文件  getCacheDir
            File file = new File( Objects.requireNonNull( getApplicationContext() ).getCacheDir(), "/weChatInfo.txt" );
            BufferedReader reader = new BufferedReader( new FileReader( file ) );
            String line = reader.readLine();
            //4.把数据按“#”分割成几部分
            if (line.contains( "#" )) {
                mData = line.split( "#" );
            }
            assert mData != null;
            meTextName.setText( mData[0] );
            meWeChatUsername.setText( mData[1] );

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            this.finish();
        }
        return super.onOptionsItemSelected( item );
    }
}
