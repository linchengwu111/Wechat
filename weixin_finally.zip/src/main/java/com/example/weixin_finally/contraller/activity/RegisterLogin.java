package com.example.weixin_finally.contraller.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.example.weixin_finally.R;
/**
 * 微信登录注册页面
 */
public class RegisterLogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_register_login );
        ActionBar supportActionBar = getSupportActionBar();
        if (supportActionBar != null) {
            supportActionBar.hide();
        }
    }

    public void registerClick(View v) {
        Intent intent = new Intent( this, RegisterActivity.class );
        startActivity( intent );
    }

    public void loginClick(View v) {
        Intent intent = new Intent( this, LoginActivity.class );
        startActivity( intent );
    }

}
