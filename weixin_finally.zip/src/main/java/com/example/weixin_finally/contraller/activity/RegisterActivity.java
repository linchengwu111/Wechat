package com.example.weixin_finally.contraller.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.weixin_finally.R;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
/**
 * 登录页面
 */
public class RegisterActivity extends AppCompatActivity {
    private EditText mUsername;
    private EditText mPassport;
    private String[] mDataS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_register );
        mUsername = findViewById( R.id.username );
        mPassport = findViewById( R.id.psd );
        ActionBar supportActionBar = getSupportActionBar();
        if (supportActionBar != null) {
            supportActionBar.hide();
        }

    }

    public void back_registerClick(View v) {
        Intent intent = new Intent( this, RegisterLogin.class );
        startActivity( intent );
    }

    public void loginWeChatClick(View v) {
        String username = mUsername.getText().toString();
        String password = mPassport.getText().toString();
        try {
            //1.找到文件
            File file = new File( getCacheDir(), "/weChatInfo.txt" );
            //2.如果文件存在，并且有数据，那么判断输入的账号密码是否一致，
            //如果输入的账号和密码与注册的账号密码一致，那么就登录成功
            //否则登录失败
            if (file.exists() && file.length() > 0) {
                //3.显示到控件里面去  读取字符串的操作  abc#123
                BufferedReader reader = new BufferedReader( new FileReader( file ) );
                String line = reader.readLine();
                //4.把数据按“#”分割成几部分
                if (line.contains( "#" )) {
                    mDataS = line.split( "#" );
                }
                if (username.equals( mDataS[1] ) && password.equals( mDataS[2] )) {
                    Intent intent = new Intent( this, MainActivity.class );
                    startActivity( intent );
                } else {
                    Toast.makeText( this, "账号或密码出错，请检查，" +
                                    "如果还没有注册，请先注册，如果忘记了账号或者密码，可重新注册！",
                            Toast.LENGTH_SHORT ).show();
                }
            } else {
                //如果文件不存在或者文件的长度=0，那么就说明没有注册，便提示先注册一下
                Toast.makeText( this, "请先注册再来登录！", Toast.LENGTH_SHORT ).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
