package com.example.weixin_finally.contraller.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.weixin_finally.R;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
/**
 * 注册页面
 */
public class LoginActivity extends AppCompatActivity {
    private EditText mName;
    private EditText mUsername;
    private EditText mPassport;
    private EditText mRePassport;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_login );
        mName = findViewById( R.id.ed_name );
        mUsername = findViewById( R.id.ed_username );
        mPassport = findViewById( R.id.ed_psd );
        mRePassport = findViewById( R.id.ed_rePsd );
        ActionBar supportActionBar = getSupportActionBar();
        if (supportActionBar != null) {
            supportActionBar.hide();
        }
    }

    public void back_registerClick(View v) {
        Intent intent = new Intent( this, RegisterLogin.class );
        startActivity( intent );
    }

    public void loginUsernameClick(View v) {
        //得到用户输入在输入框的文本
        String name = mName.getText().toString();
        String username = mUsername.getText().toString();
        String passWord = mPassport.getText().toString();
        String rePassWord = mRePassport.getText().toString();
        // passport==null||passport.equals("")
        // TextUtils.isEmpty()
        /*判断四个文本是否有一个为空，有则显示让用户去填写完整
         * */
        if (TextUtils.isEmpty( name ) || TextUtils.isEmpty( username )
                || TextUtils.isEmpty( passWord ) || TextUtils.isEmpty( rePassWord )) {
            Toast.makeText( this, "请填写完整的信息", Toast.LENGTH_SHORT ).show();
            return;
        }
        // 登录保存数据
        saveData( name, username, passWord, rePassWord );
    }

    private void saveData(String name, String username, String passWord, String rePassWord) {
        //判断是否两次密码一致，不一致先填写一致，再对数据进行保存
        if (passWord.equals( rePassWord )) {
            try {
                File file = new File( getCacheDir(), "/weChatInfo.txt" );
                //2.显示到控件里面去  读取字符串的操作  abc#123
                BufferedWriter writer = new BufferedWriter( new FileWriter( file ) );
                writer.write( name + "#" + username + "#" + passWord );
                writer.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            //3.注册成功后显示
            Toast.makeText( this, "恭喜您，注册成功！可以去登录了！", Toast.LENGTH_SHORT ).show();

        } else {
            //如果两次密码不一致，则先显示不一致，密码一致再保存数据
            Toast.makeText( this, "两次密码不一致，请检查！", Toast.LENGTH_SHORT ).show();

        }

    }
}
