package com.example.weixin_finally.contraller.activity;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.SparseArray;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.weixin_finally.R;
import com.example.weixin_finally.View.TabView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
/**
 * 微信首页的整理框架
 */
public class MainActivity extends AppCompatActivity {
    private ViewPager mVpMain;
    private ArrayList<TabView> mTabs = new ArrayList<>();
    private SparseArray<TabFragment> mTabFragments = new SparseArray<>();
    private List<String> mTitles = new ArrayList<>( Arrays.asList( "微信", "通讯录", "发现", "我" ) );
    private static final String BUNDLE_KEY_POS = "bundle_key_pos";
    private int mCurTabPos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
        mVpMain = findViewById( R.id.vp_main );
        if (savedInstanceState != null) {
            mCurTabPos = savedInstanceState.getInt( BUNDLE_KEY_POS, 0 );
        }
        initViews();
        initViewPagerAdapter();
        initEvents();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate( R.menu.main, menu );
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_groupChat:
                Toast.makeText( this, "发起群聊", Toast.LENGTH_SHORT ).show();
                return true;
            case R.id.action_AddFriend:
                Toast.makeText( this, "添加朋友", Toast.LENGTH_SHORT ).show();
                return true;
            case R.id.action_Scan:
                Toast.makeText( this, "扫一扫", Toast.LENGTH_SHORT ).show();
                return true;
            case R.id.action_receiving:
                Toast.makeText( this, "收付款", Toast.LENGTH_SHORT ).show();
                return true;
            case R.id.action_helping:
                Toast.makeText( this, "帮助与反馈", Toast.LENGTH_SHORT ).show();
                return true;
            default:
                return super.onOptionsItemSelected( item );
        }
    }


    private void initEvents() {
        for (int i = 0; i < mTabs.size(); i++) {
            TabView tabView = mTabs.get( i );
            final int finalI = i;
            tabView.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mVpMain.setCurrentItem( finalI, false );
                    setCurrentTab( finalI );
                }
            } );
        }
    }


    public void initViewPagerAdapter() {
        mVpMain.setAdapter( new FragmentPagerAdapter( getSupportFragmentManager() ) {
            @Override
            public Fragment getItem(int i) {
                final TabFragment tabFragment = TabFragment.newInstance( mTitles.get( i ) );
                return tabFragment;
            }


            @Override
            public int getCount() {
                return mTitles.size();
            }

            @NonNull
            @Override
            public Object instantiateItem(@NonNull ViewGroup container, int position) {
                TabFragment tabfragment = (TabFragment) super.instantiateItem( container, position );
                mTabFragments.put( position, tabfragment );
                return tabfragment;
            }

            @Override
            public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
                mTabFragments.remove( position );
                super.destroyItem( container, position, object );

            }
        } );

        mVpMain.addOnPageChangeListener( new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int i, float v, int i1) {
                if (v > 0) {
                    TabView left = mTabs.get( i );
                    TabView right = mTabs.get( i + 1 );
                    left.setProgress( 1 - v );
                    right.setProgress( v );
                }
                if (i == 0) {
                    setTitle( "微信" );
                }
                if (i == 1) {
                    setTitle( "通讯录" );
                }
                if (i == 2) {
                    setTitle( "发现" );
                }
                if (i == 3) {
                    setTitle( " " );
                }

            }

            @Override
            public void onPageSelected(int i) {

            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        } );
    }


    public void initViews() {
        TabView mBtnWeChat = findViewById( R.id.btn_weChat );
        TabView mBtnAddressList = findViewById( R.id.btn_addressList );
        TabView mBtnDiscover = findViewById( R.id.btn_discover );
        TabView mBtnMe = findViewById( R.id.btn_me );
        mBtnWeChat.setIconAndText( R.drawable.tab_wechat, R.drawable.tab_wechats, "微信" );
        mBtnAddressList.setIconAndText( R.drawable.tab_friend, R.drawable.tab_friends, "通讯录" );
        mBtnDiscover.setIconAndText( R.drawable.tab_find, R.drawable.tab_finds, "发现" );
        mBtnMe.setIconAndText( R.drawable.mine, R.drawable.mines, "我" );

        mTabs.add( mBtnWeChat );
        mTabs.add( mBtnAddressList );
        mTabs.add( mBtnDiscover );
        mTabs.add( mBtnMe );
        mBtnWeChat.setProgress( 1 );

        setCurrentTab( mCurTabPos );
    }

    private void setCurrentTab(int pos) {
        for (int i = 0; i < mTabs.size(); i++) {
            TabView tabView = mTabs.get( i );
            if (i == pos) {
                tabView.setProgress( 1 );
            } else {
                tabView.setProgress( 0 );
            }

        }
    }

    //保存当前的位置，使得屏幕旋转和横屏，应用的位置不发生改变
    @Override
    public void onSaveInstanceState(Bundle outState) {

        outState.putInt( BUNDLE_KEY_POS, mVpMain.getCurrentItem() );
        super.onSaveInstanceState( outState );
    }
}