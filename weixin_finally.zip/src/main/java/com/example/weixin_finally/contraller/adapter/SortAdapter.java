package com.example.weixin_finally.contraller.adapter;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.weixin_finally.R;

import java.util.List;

/**
 * 通讯录好友的设配器
 */
public class SortAdapter extends BaseAdapter {

    private List<User> list = null;
    private Context mContext;

    public SortAdapter(Context mContext, List<User> list) {
        this.mContext = mContext;
        this.list = list;
    }

    public int getCount() {
        return this.list.size();
    }

    public Object getItem(int position) {
        return list.get( position );
    }

    public long getItemId(int position) {
        return position;
    }

    public View getView(final int position, View view, ViewGroup arg2) {
        ViewHolder viewHolder;
        final User user = list.get( position );
        if (view == null) {
            viewHolder = new ViewHolder();
            view = LayoutInflater.from( mContext ).inflate( R.layout.item, null );
            viewHolder.username = view.findViewById( R.id.friends_username );
            viewHolder.catalog = view.findViewById( R.id.catalog );
            viewHolder.imageView = view.findViewById( R.id.friends_image );
            view.setTag( viewHolder );
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }


        if (list.get( position ).getName().equals( "新的朋友" )) {
            viewHolder.catalog.setVisibility( View.GONE );
            viewHolder.imageView.setImageResource( R.drawable.friends_1 );
        } else if (list.get( position ).getName().equals( "群聊" )) {
            viewHolder.catalog.setVisibility( View.GONE );
            viewHolder.imageView.setImageResource( R.drawable.friends_2 );
        } else if (list.get( position ).getName().equals( "标签" )) {
            viewHolder.catalog.setVisibility( View.GONE );
            viewHolder.imageView.setImageResource( R.drawable.friends_3 );
        } else if (list.get( position ).getName().equals( "公众号" )) {
            viewHolder.catalog.setVisibility( View.GONE );
            viewHolder.imageView.setImageResource( R.drawable.friends_4 );
        } else {
            //根据position获取首字母作为目录catalog
            String catalog = list.get( position ).getFirstLetter();
            //如果当前位置等于该分类首字母的Char的位置 ，则认为是第一次出现
            if (position == getPositionForSection( catalog )) {
                viewHolder.catalog.setVisibility( View.VISIBLE );
                viewHolder.catalog.setText( user.getFirstLetter().toUpperCase() );
            } else {
                viewHolder.catalog.setVisibility( View.GONE );
            }
            viewHolder.imageView.setImageResource( R.drawable.ig_friends );
        }
            viewHolder.username.setText( this.list.get( position ).getName() );

        return view;

    }

    final static class ViewHolder {
        TextView catalog;
        TextView username;
        ImageView imageView;
    }

    /**
     * 获取catalog首次出现位置
     */
    public int getPositionForSection(String catalog) {
        for (int i = 0; i < getCount(); i++) {
            String sortStr = list.get( i ).getFirstLetter();
            if (catalog.equalsIgnoreCase( sortStr )) {
                return i;
            }
        }
        return -1;
    }

}