package com.example.weixin_finally.View;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.weixin_finally.R;

/**
 * 自定义控件
 *
 */

public class itemView extends RelativeLayout {
    private ImageView imageViewLeft;
    private TextView textView;
    private ImageView iconArrows;
    private RelativeLayout relativeLayout;

    public itemView(Context context, AttributeSet attrs) {
        super( context, attrs );
        LayoutInflater.from( context ).inflate( R.layout.item_layout, this );
        iconArrows = findViewById( R.id.iconArrows );
        textView = findViewById( R.id.textView );
        imageViewLeft = findViewById( R.id.imageViewLeft );
        relativeLayout = findViewById( R.id.myRelativeLayout );
        TypedArray typedArray=context.obtainStyledAttributes( attrs, R.styleable.itemView );
        String textView = typedArray.getString( R.styleable.itemView_textView );
        boolean isShowArrows = typedArray.getBoolean( R.styleable.itemView_isShowArrows, true );


    }


    public void setItemView(int imageViewLeft,String textView,boolean isShowArrow) {
        if (imageViewLeft != 0) {
            this.imageViewLeft.setImageResource( imageViewLeft );

        }
        if (textView != null) {
            this.textView.setText( textView );

        }
        if (isShowArrow) {
            iconArrows.setVisibility( View.VISIBLE );//箭头显示
        } else {
            iconArrows.setVisibility( View.GONE );//箭头消失
        }
    }

    public void setOnItemViewClickListener(OnClickListener onClickListener) {
        relativeLayout.setOnClickListener( onClickListener );

    }

}
