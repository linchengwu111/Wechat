package com.example.weixin_finally.View;

import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.weixin_finally.R;

/**
 * 自定义四个tab控件
 */
public class TabView extends FrameLayout {
    private ImageView miv_icon;
    private ImageView miv_icon_select;
    private TextView mtv_title;
    private static final int COLOR_DEFAULT = Color.parseColor("#ff000000");
    private static final int COLOR_SELECT = Color.parseColor("#FF45C01A");

    public void setIconAndText(int icon, int icon_select, String text) {
        miv_icon.setImageResource(icon);
        miv_icon_select.setImageResource(icon_select);
        mtv_title.setText(text);
        setProgress(0);

    }
    public TabView(@NonNull Context context, @NonNull AttributeSet attrs) {
        super(context, attrs);
        inflate(context, R.layout.tab_view, this);
        miv_icon = findViewById(R.id.iv_icon);
        miv_icon_select = findViewById(R.id.iv_icon_select);
        mtv_title = findViewById(R.id.tv_title);
    }
    public void setProgress(float progress) {
        miv_icon.setAlpha(1 - progress);
        miv_icon_select.setAlpha(progress);
        mtv_title.setTextColor(evaluate(progress, COLOR_DEFAULT, COLOR_SELECT));
    }
    //从intVa
    public int evaluate(float fraction, int startValue, int endValue) {
        float startA = (float)(startValue >> 24 & 255) / 255.0F;
        float startR = (float)(startValue >> 16 & 255) / 255.0F;
        float startG = (float)(startValue >> 8 & 255) / 255.0F;
        float startB = (float)(startValue & 255) / 255.0F;
        float endA = (float)(endValue >> 24 & 255) / 255.0F;
        float endR = (float)(endValue >> 16 & 255) / 255.0F;
        float endG = (float)(endValue >> 8 & 255) / 255.0F;
        float endB = (float)(endValue & 255) / 255.0F;
        startR = (float)Math.pow((double)startR, 2.2D);
        startG = (float)Math.pow((double)startG, 2.2D);
        startB = (float)Math.pow((double)startB, 2.2D);
        endR = (float)Math.pow((double)endR, 2.2D);
        endG = (float)Math.pow((double)endG, 2.2D);
        endB = (float)Math.pow((double)endB, 2.2D);
        float a = startA + fraction * (endA - startA);
        float r = startR + fraction * (endR - startR);
        float g = startG + fraction * (endG - startG);
        float b = startB + fraction * (endB - startB);
        a *= 255.0F;
        r = (float)Math.pow((double)r, 0.45454545454545453D) * 255.0F;
        g = (float)Math.pow((double)g, 0.45454545454545453D) * 255.0F;
        b = (float)Math.pow((double)b, 0.45454545454545453D) * 255.0F;
        return Math.round(a) << 24 | Math.round(r) << 16 | Math.round(g) << 8 | Math.round(b);
    }
}
